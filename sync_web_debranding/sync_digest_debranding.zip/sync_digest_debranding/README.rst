1. Replace the digest name as weekly stats for debrand digest module.
